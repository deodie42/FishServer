package kr.co.controller;

import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.service.BoardService;
import kr.co.service.BoardsService;
import kr.co.vo.BoardCategoryVO;
import net.sf.json.JSONArray;


@Controller
@RequestMapping("/board/*")
public class BoardsController {
	private static final Logger logger = LoggerFactory.getLogger(BoardsController.class);
	
	@Inject
	BoardsService boardsService;

	//게시판 연습
	@RequestMapping(value = "/boards/mainbd", method = RequestMethod.GET)
	public void getmadinbd() throws Exception {
	 logger.info("get mainbd");
	}
	
	//자유 게시판
	@RequestMapping(value = "/boards/freebd", method = RequestMethod.GET)
	public void getfreebd(Model model) throws Exception {
	 logger.info("get freebd");
	 
	 
	 List<BoardCategoryVO> boardcate = null;
	 boardcate = boardsService.boardcate();
	 	model.addAttribute("boardcate", JSONArray.fromObject(boardcate));
	 
	}
	
}
