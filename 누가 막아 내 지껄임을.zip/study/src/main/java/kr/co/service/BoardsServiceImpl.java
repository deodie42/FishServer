package kr.co.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;


import kr.co.dao.BoardsDAO;
import kr.co.vo.BoardCategoryVO;

@Service
public class BoardsServiceImpl implements BoardsService{

	
	@Inject
	private BoardsDAO bao;
	
	// 카테고리
	@Override
	public List<BoardCategoryVO> boardcate() throws Exception{
		return bao.boardcate();
		
		
	}
	
}
