package kr.co.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import kr.co.dao.AdminDAO;
import kr.co.vo.AdminVO;
import kr.co.vo.BoardVO;
import kr.co.vo.SearchCriteria;

@Service
public class AdminServiceImpl implements AdminService{
	@Inject
	private AdminDAO ado;
	

	// 낚시용품  작성
	@Override
	
	public void prite(AdminVO adminVO) throws Exception {
		ado.prite(adminVO);
	}

	
	// 유료낚시터 작성
	@Override
	
	public void srite(AdminVO adminVO) throws Exception {
		ado.srite(adminVO);
	}
	
	// 낚시 용품 리스트 보기
	@Override
	public List<AdminVO> plist() throws Exception {

		return ado.plist();
	}
	
	

	// 낚시 용품 리스트 상세 페이지 보기
	@Override
	public AdminVO pead(int pno) throws Exception {

		return ado.pead(pno);
	}
	
	// 게시글 수정
	@Override
	public void pdate(AdminVO adminVO) throws Exception {

		ado.pdate(adminVO);
	}
	// 게시글 삭제
	@Override
	public void pelete(int pno) throws Exception {
		
		ado.pelete(pno);
	}
	
}
