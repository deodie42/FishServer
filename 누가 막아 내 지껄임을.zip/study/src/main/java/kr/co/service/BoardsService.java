package kr.co.service;

import java.util.List;

import kr.co.vo.BoardCategoryVO;

public interface BoardsService {
		
	
	
	//카테고리
	public List<BoardCategoryVO> boardcate() throws Exception;
	
}
