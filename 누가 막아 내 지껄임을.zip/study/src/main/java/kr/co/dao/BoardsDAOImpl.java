package kr.co.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import kr.co.vo.BoardCategoryVO;

@Repository
public class BoardsDAOImpl implements BoardsDAO{

	@Inject
	private SqlSession sql;
	
	
	//매퍼
	private static String namespace = "boardsMapper";
	
	
	
	//카테고리
	@Override
	public List<BoardCategoryVO> boardcate() throws Exception{
		return sql.selectList(namespace + ".boardcate");
		
	}
}
