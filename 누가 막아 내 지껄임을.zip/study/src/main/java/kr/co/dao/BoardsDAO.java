package kr.co.dao;

import java.util.List;

import kr.co.vo.BoardCategoryVO;

public interface BoardsDAO {

	
	
	
	
	
	
	//카테고리
	public List<BoardCategoryVO>  boardcate() throws Exception;
}
