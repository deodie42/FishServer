package kr.co.vo;

import java.util.Date;

public class BoardVO {

	
			private int bno;
			private String title;
			private String content;
			private String writer;
			private Date regdate;
			private int hit;

			
			private int fno;
			private String fitle;
			private String fontent;
			private String friter;
			private Date fegdate;
			
			
			
			
			
			
			
			
			
			
			
			
			
			
	
			
			
			
			
			public int getHit() {
				return hit;
			}
			public void setHit(int hit) {
				this.hit = hit;
			}
			public int getFno() {
				return fno;
			}
			public void setFno(int fno) {
				this.fno = fno;
			}
			public String getFitle() {
				return fitle;
			}
			public void setFitle(String fitle) {
				this.fitle = fitle;
			}
			public String getFontent() {
				return fontent;
			}
			public void setFontent(String fontent) {
				this.fontent = fontent;
			}
			public String getFriter() {
				return friter;
			}
			public void setFriter(String friter) {
				this.friter = friter;
			}
			public Date getFegdate() {
				return fegdate;
			}
			public void setFegdate(Date fegdate) {
				this.fegdate = fegdate;
			}
			public int getBno() {
				return bno;
			}
			public void setBno(int bno) {
				this.bno = bno;
			}
			public String getTitle() {
				return title;
			}
			public void setTitle(String title) {
				this.title = title;
			}
			public String getContent() {
				return content;
			}
			public void setContent(String content) {
				this.content = content;
			}
			public String getWriter() {
				return writer;
			}
			public void setWriter(String writer) {
				this.writer = writer;
			}
			public Date getRegdate() {
				return regdate;
			}
			public void setRegdate(Date regdate) {
				this.regdate = regdate;
			}
			
}
