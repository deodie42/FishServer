package kr.co.vo;

public class CategoryVO {

}
