package kr.co.vo;

import java.util.Date;

public class ReplyVO {

	
	private int fno;
	private int freerno;
	private String freecontent;
	private String freewriter;
	private Date freeregdate;
	
	
	public int getFno() {
		return fno;
	}
	public void setFno(int fno) {
		this.fno = fno;
	}
	public int getFreerno() {
		return freerno;
	}
	public void setFreerno(int freerno) {
		this.freerno = freerno;
	}
	public String getFreecontent() {
		return freecontent;
	}
	public void setFreecontent(String freecontent) {
		this.freecontent = freecontent;
	}
	public String getFreewriter() {
		return freewriter;
	}
	public void setFreewriter(String freewriter) {
		this.freewriter = freewriter;
	}
	public Date getFreeregdate() {
		return freeregdate;
	}
	public void setFreeregdate(Date freeregdate) {
		this.freeregdate = freeregdate;
	}
	
	
	
	
}
