package com.fish.myapp.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fish.myapp.domain.BoardVo;
import com.fish.myapp.persistence.BoardService_Mapper;

@Service("BoardServiceImpl")
public class BoardServiceImpl implements BoardService{
	
	@Autowired
	SqlSession sqlSession;
	
	@Override
	public ArrayList<BoardVo> boardSelectAll() {
		ArrayList<BoardVo> alist = null;
		BoardService_Mapper bsm =sqlSession.getMapper(BoardService_Mapper.class);	
		alist = bsm.boardSelectAll();
		return alist;
	}	
	
	@Override
	public BoardVo boardSelectOne(int bidx) {
		BoardService_Mapper bsm = sqlSession.getMapper(BoardService_Mapper.class);
		BoardVo bv = bsm.boardSelectOne(bidx);			
		return bv;
	}
	
	@Override
	public int boardInsert(String title, String content, String writer, String pwd) {

		HashMap<String,Object> hm = new HashMap<String,Object>();
		hm.put("title", title);
		hm.put("content", content);
		hm.put("writer", writer);
		hm.put("pwd", pwd);		
		
		BoardService_Mapper bsm = sqlSession.getMapper(BoardService_Mapper.class);
		int result = bsm.boardInsert(hm);
		
		return result;
	}		
	

	@Override
	public int boardModify(int bidx, String title, String content, String writer, String pwd) {
		HashMap<String,Object> hm = new HashMap<String,Object>();
		hm.put("bidx", bidx);
		hm.put("title", title);
		hm.put("content", content);
		hm.put("writer", writer);
		hm.put("pwd", pwd);		
		
		BoardService_Mapper bsm = sqlSession.getMapper(BoardService_Mapper.class);
		int result = bsm.boardModify(hm);
		
		return result;
	}
		
	@Override
	public int boardDelete(int bidx) {
		HashMap<String,Object> hm = new HashMap<String,Object>();
		hm.put("bidx", bidx);
		
		BoardService_Mapper bsm = sqlSession.getMapper(BoardService_Mapper.class);
		int result = bsm.boardDelete(hm);		
		return result;
	}

	@Override
	public ArrayList<BoardVo> boardTopList() {
		BoardService_Mapper bsm =sqlSession.getMapper(BoardService_Mapper.class);	
		ArrayList<BoardVo> alist = bsm.boardTopList();
		return alist;
	}


}
