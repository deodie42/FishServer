package com.fish.myapp.service;

import com.fish.myapp.domain.MemberVo;

public interface MemberService {

	public int memberJoin(String Id, String password, String name, String gender, String phone);
	
	public int memberModify(int midx, String Id, String password, String name, String birth, String gender, String email,
			String phone, int age, String address);
	public int memberDelete(int midx);

	public MemberVo memberLogin(String memberid, String memberpwd);

	public MemberVo memberCheckId(String membername, String memberphone);

}
